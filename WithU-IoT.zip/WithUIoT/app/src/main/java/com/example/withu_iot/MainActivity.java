package com.example.withu_iot;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.StringTokenizer;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private TextView register;
    private Button login;
    private EditText email, password;

    private FirebaseAuth mAuth;
    SharedPreferences sharedpreferences;
    int autoSave;
    private static final String LOG_TAG = "PowerPress";

    //private MyReceiver myReceiver;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        register = (TextView) findViewById(R.id.register);
        register.setOnClickListener(this);

        login = (Button) findViewById(R.id.login);
        login.setOnClickListener(this);

        email = (EditText) findViewById(R.id.login_email);
        password = (EditText) findViewById(R.id.login_password);

        //View backgroundImage = findViewById(R.id.);
        //Drawable background = backgroundImage.getBackground();
        //background.setAlpha(80);

        mAuth = FirebaseAuth.getInstance();

        FirebaseUser user = mAuth.getCurrentUser();

        sharedpreferences = getSharedPreferences("login",MODE_PRIVATE);
        if(sharedpreferences.getBoolean("logged",false)){
            //goToMainActivity();
            startActivity(new Intent(MainActivity.this, MainPage.class));
        }

        //"autoLogin" is a unique string to identify the instance of this shared preference
        /*sharedpreferences = getSharedPreferences("autoLogin", Context.MODE_PRIVATE);
        int j = sharedpreferences.getInt("key", 0);

        //Default is 0 so autologin is disabled
        if(j > 0)
        {
            Intent activity = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(activity);
        }*/

        /*if(user != null)
        {
            //put intent to go to mainActivity
            startActivity(new Intent(MainActivity.this,MainPage.class));
            this.finish();

        }*/

    }
    int count = 0;
    boolean press_flag = false;
    //@Override
    /*public boolean onKeyDown(int keyCode, KeyEvent event)
    {
        //Toast.makeText(MainActivity.this, "Hey!", Toast.LENGTH_LONG).show();
        if(KeyEvent.KEYCODE_VOLUME_DOWN == event.getKeyCode())
        {
            //startActivity(new Intent(MainActivity.this, MapsActivity.class));
            //Toast.makeText(MainActivity.this, "Volume pressed!", Toast.LENGTH_LONG).show();
            long l = 0;
            if(l == 0)
            {
                l=System.currentTimeMillis();
            }//clicked first time
            else {
                l = System.currentTimeMillis() - l;
                press_flag = true;
            }
            //Log.e("In MainActivity", "Power key detected");
            /*String message = "My current location is:" + "\t" + currentLocation;

            String phoneNo = "7045659459";

            StringTokenizer st = new StringTokenizer(phoneNo, ",");
            while (st.hasMoreElements()) {
                String tempMobileNumber = (String) st.nextElement();
                if (tempMobileNumber.length() > 0 && message.trim().length() > 0) {
                    sendSMS(tempMobileNumber, message);
                } else {
                    Toast.makeText(getBaseContext(),
                            "Please enter both phone number and message.",
                            Toast.LENGTH_SHORT).show();
                }
                return true;

            count++;
            if(count==3)
            {
                Toast.makeText(getBaseContext(),
                        "Power Button pressed three times!",
                        Toast.LENGTH_SHORT).show();
                count=0;
            }*/
            /*if(press_flag)
            {
                Log.e(LOG_TAG, "SMS on!");
                startActivity(new Intent(MainActivity.this, MapsActivity.class));
                l = 0;
            }
        }
        return super.onKeyDown(keyCode, event);
    }*/



    @Override
    public void onClick(View v)
    {
        switch(v.getId())
        {
            case R.id.register:
                startActivity(new Intent(this, RegisterUser.class));
                break;
            case R.id.login:
                userLogin();
                break;
        }
    }

    private void userLogin()
    {
        String user_email = email.getText().toString().trim();
        String user_password = password.getText().toString().trim();

        if(user_email.isEmpty())
        {
            email.setError("Email-ID is required!");
            email.requestFocus();
            return;
        }
        if(!Patterns.EMAIL_ADDRESS.matcher(user_email).matches())
        {
            email.setError("Please provide a valid Email-Id!");
            email.requestFocus();
            return;
        }
        if(user_password.isEmpty())
        {
            password.setError("Password is required!");
            password.requestFocus();
            return;
        }
        if(user_password.length() < 6)
        {
            password.setError("Min length should be 6 characters!");
            password.requestFocus();
            return;
        }

        mAuth.signInWithEmailAndPassword(user_email,user_password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task)
            {
                if(task.isSuccessful())
                {
                    // redirect to user profile
                    startActivity(new Intent(MainActivity.this,MainPage.class));
                    sharedpreferences.edit().putBoolean("logged",true).apply();
                }
                else{
                    Toast.makeText(MainActivity.this, "Failed to Login! Please check your credentials", Toast.LENGTH_LONG).show();
                }
            }
        });

        //Once you click login, it will add 1 to shredPreference which will allow autologin in onCreate
        /*autoSave = 1;
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putInt("key", autoSave);
        editor.apply();*/


    }
}