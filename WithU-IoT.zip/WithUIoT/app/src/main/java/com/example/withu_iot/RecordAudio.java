package com.example.withu_iot;

import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.ContextWrapper;
import android.content.Intent;
import android.os.Bundle;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.File;
import java.io.IOException;

import static android.Manifest.permission.RECORD_AUDIO;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;

public class RecordAudio extends AppCompatActivity implements View.OnClickListener{

    private Button start_record, stop_record, play_audio, stop_audio;
    private TextView textView;

    // creating a variable for media recorder object class.
    private MediaRecorder mRecorder = new MediaRecorder();

    // creating a variable for mediaplayer class
    private MediaPlayer mPlayer;

    private static final String LOG_TAG = "AudioRecording";

    // string variable is created for storing a file name
    private static String mFileName = null;

    // constant for storing audio permission
    public static final int REQUEST_AUDIO_PERMISSION_CODE = 1;

    public static final int SAMPLING_RATE = 44100;

    //private MediaRecorder mediaRecorder;
    //private MediaPlayer mediaPlayer;
    //public static String fileName = "recorded.3gp";
    //String file = Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator + fileName;
    //String file = Environment.getExternalStorageDirectory().getAbsolutePath() + "/recorded.3gp";


    //private static int MICR0PHONE_PERMISSION_CODE = 200;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_record_audio);

        start_record = findViewById(R.id.record_audio_btn);
        //start_record.setOnClickListener(this);
        stop_record = findViewById(R.id.stop_audio_btn);
        //stop_record.setOnClickListener(this);
        play_audio = findViewById(R.id.play_audio_btn);
        //stop_audio = findViewById(R.id.stop_play_btn);

        start_record.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(CheckPermissions())
                {
                    mFileName = Environment.getExternalStorageDirectory().getAbsolutePath() + "/recorded.mp3";
                    mRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
                    mRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
                    mRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
                    mRecorder.setOutputFile(mFileName);
                    //mRecorder.setAudioSamplingRate(SAMPLING_RATE);
                    //mRecorder.setAudioEncodingBitRate(64000);
                    try
                    {
                        mRecorder.prepare();
                        mRecorder.start();
                        Toast.makeText(RecordAudio.this, "Recording Started!", Toast.LENGTH_LONG).show();
                    }
                    catch(IOException e)
                    {
                        Log.e(LOG_TAG, "prepare() failed");
                    }
                }
                else
                {
                    RequestPermissions();
                }
            }

        });

        stop_record.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //if(mRecorder != null)
                //{
                    mRecorder.stop();
                    mRecorder.release();
                    //mRecorder = null;
                    Toast.makeText(RecordAudio.this, "Recording Stopped!", Toast.LENGTH_LONG).show();
                //}
            }
        });

        play_audio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // play audio method will play
                // the audio which we have recorded
                mPlayer = new MediaPlayer();
                try {
                    mPlayer.setDataSource(mFileName);
                    mPlayer.prepare();
                    mPlayer.start();
                    Toast.makeText(RecordAudio.this, "Recording Started Playing!", Toast.LENGTH_LONG).show();
                } catch (IOException e) {
                    Log.e(LOG_TAG, "prepare() failed");
                }
            }
        });
        /*stop_audio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // pause play method will
                // pause the play of audio
                pausePlaying();
            }
        });*/
    }

    @Override
    public void onClick(View view)
    {
        /*if(view.getId() == R.id.record_audio_btn) {
            startRecording();
        }
        else if(view.getId() == R.id.stop_audio_btn) {
            pauseRecording();
        }
        else if(view.getId() == R.id.play_audio_btn) {
            playRecording();
        }*/
    }




    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case REQUEST_AUDIO_PERMISSION_CODE:
                if (grantResults.length > 0) {
                    boolean permissionToRecord = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                    boolean permissionToStore = grantResults[1] == PackageManager.PERMISSION_GRANTED;
                    if (permissionToRecord && permissionToStore) {
                        Toast.makeText(getApplicationContext(), "Permission Granted", Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(getApplicationContext(), "Permission Denied", Toast.LENGTH_LONG).show();
                    }
                }
                break;
        }
    }

    public boolean CheckPermissions()
    {
        int result = ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.WRITE_EXTERNAL_STORAGE);
        int result1 = ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.RECORD_AUDIO);
        return result == PackageManager.PERMISSION_GRANTED && result1 == PackageManager.PERMISSION_GRANTED;
    }

    private void RequestPermissions() {
        ActivityCompat.requestPermissions(RecordAudio.this, new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_AUDIO_PERMISSION_CODE);
    }


}