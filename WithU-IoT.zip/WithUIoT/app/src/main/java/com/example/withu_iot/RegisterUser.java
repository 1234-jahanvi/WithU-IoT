package com.example.withu_iot;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class RegisterUser extends AppCompatActivity implements View.OnClickListener{

    private FirebaseAuth mAuth;

    private EditText user_email,user_password,user_age,user_fullname, user_emergency1, user_emergency2;
    private TextView registerUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_user);

        mAuth = FirebaseAuth.getInstance();

        registerUser = (Button) findViewById(R.id.registeruser);
        registerUser.setOnClickListener(this);

        user_fullname = (EditText) findViewById(R.id.fullname);
        user_age = (EditText) findViewById(R.id.age);
        user_email = (EditText) findViewById(R.id.email);
        user_password = (EditText) findViewById(R.id.password);
        user_emergency1 = (EditText) findViewById(R.id.emergency1);
        user_emergency2 = (EditText) findViewById(R.id.emergency2);

    }

    @Override
    public void onClick(View v)
    {
        switch(v.getId())
        {
            case R.id.registeruser:
                registerUser_method();
                startActivity(new Intent(this, MainActivity.class));
                break;
                
        }
    }

    private void registerUser_method()
    {
        String email = user_email.getText().toString().trim();
        String fullname = user_fullname.getText().toString().trim();
        String age = user_age.getText().toString().trim();
        String password = user_password.getText().toString().trim();
        String emergency_contact_1 = user_emergency1.getText().toString().trim();
        String emergency_contact_2 = user_emergency2.getText().toString().trim();

        if(fullname.isEmpty())
        {
            user_fullname.setError("Full Name is required!");
            user_fullname.requestFocus();
            return;
        }
        if(age.isEmpty())
        {
            user_age.setError("Age is required!");
            user_age.requestFocus();
            return;
        }
        if(email.isEmpty())
        {
            user_email.setError("Email-Id is required!");
            user_email.requestFocus();
            return;
        }
        if(!Patterns.EMAIL_ADDRESS.matcher(email).matches())
        {
            user_email.setError("Please provide a valid Email-Id!");
            user_email.requestFocus();
            return;
        }
        if(password.isEmpty())
        {
            user_fullname.setError("Password is required!");
            user_fullname.requestFocus();
            return;
        }
        if(password.length() < 6)
        {
            user_password.setError("Min length should be 6 characters!");
            user_password.requestFocus();
            return;
        }
        if(emergency_contact_1.isEmpty())
        {
            user_emergency1.setError("Emergency Contact - 1 is required!");
            user_emergency1.requestFocus();
            return;
        }
        if(emergency_contact_1.length() != 10)
        {
            user_emergency1.setError("Enter a valid phone number!");
            user_emergency1.requestFocus();
            return;
        }
        if(emergency_contact_2.isEmpty())
        {
            user_emergency2.setError("Emergency Contact - 2 is required!");
            user_emergency2.requestFocus();
            return;
        }
        if(emergency_contact_2.length() != 10)
        {
            user_emergency2.setError("Enter a valid phone number!");
            user_emergency2.requestFocus();
            return;
        }


        mAuth.createUserWithEmailAndPassword(email,password)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful())
                        {
                            User user = new User(fullname,age,email,emergency_contact_1, emergency_contact_2);
                            FirebaseDatabase.getInstance().getReference("Users")
                                    .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                    .setValue(user).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if(task.isSuccessful())
                                    {
                                        Toast.makeText(RegisterUser.this,"User has been registered successfully!",Toast.LENGTH_LONG).show();
                                    }
                                    else
                                    {
                                        Toast.makeText(RegisterUser.this,"Failed to register!",Toast.LENGTH_LONG).show();
                                    }
                                }
                            });
                        }
                        else
                        {
                            Toast.makeText(RegisterUser.this,"Failed to register!",Toast.LENGTH_LONG).show();
                        }
                    }
                });

    }
}