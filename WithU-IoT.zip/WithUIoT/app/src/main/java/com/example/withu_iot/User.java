package com.example.withu_iot;

public class User
{
    public String fullname, age, email, emergency_contact_1, emergency_contact_2;

    public User()
    {

    }

    public User(String fullname, String age, String email, String emergency_contact_1, String emergency_contact_2)
    {
        this.fullname = fullname;
        this.age = age;
        this.email = email;
        this.emergency_contact_1 = emergency_contact_1;
        this.emergency_contact_2 = emergency_contact_2;
    }
}
